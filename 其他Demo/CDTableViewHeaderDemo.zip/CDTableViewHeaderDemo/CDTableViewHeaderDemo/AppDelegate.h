//
//  AppDelegate.h
//  CDTableViewHeaderDemo
//
//  Created by Alex on 15/8/21.
//  Copyright (c) 2015年 Alex. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

